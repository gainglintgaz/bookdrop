# CURRENT_SPRINT.md — BookkeeperPortal
## Update this after EVERY task. This is how Claude Code knows what to do next.

Last updated: April 2026
Sprint goal: Ship working MVP — client uploads, bookkeeper dashboard, reminders

---

## STATUS: IN PROGRESS — PHASE 1 BUILD

---

## DONE ✓
- [x] Project directory structure created
- [x] CLAUDE.md written with full spec
- [x] Database schema designed (all 6 tables)
- [x] TypeScript types defined (src/types/database.types.ts)
- [x] Tenant config system designed (src/lib/tenant.config.ts)

---

## IN PROGRESS →
- [ ] Supabase migration file (001_initial_schema.sql)
- [ ] TypeScript types (src/types/index.ts)
- [ ] Tenant config implementation
- [ ] Supabase client setup (src/lib/supabase.ts)

---

## QUEUE (do in this order after In Progress is done)

### Core Infrastructure
- [ ] Auth store (Zustand) — bookkeeper login state
- [ ] Supabase helper functions (src/lib/db.ts)
- [ ] toCents / fromCents utilities
- [ ] Error handling utilities

### Client Upload Page (build this FIRST — it's the core value)
- [ ] /upload/[token] route — public, no auth
- [ ] Fetch client requirements from portal_token
- [ ] File upload component (drag-and-drop + click)
- [ ] Upload progress indicator
- [ ] Per-requirement status (uploaded ✓ / not uploaded)
- [ ] Completion state — "You're all done!" banner
- [ ] Auto-notify bookkeeper on complete submission

### Bookkeeper Auth
- [ ] Login page
- [ ] Signup page
- [ ] Password reset
- [ ] Protected route wrapper

### Bookkeeper Dashboard
- [ ] Client list with status badges (green/yellow/red)
- [ ] Summary stats (complete/partial/missing/not started)
- [ ] Month selector (current month default)
- [ ] Per-client: Send reminder, Download all, View detail actions
- [ ] Late rate insight widget (bottom of dashboard)

### Client Management
- [ ] Add client form (all fields from spec)
- [ ] Edit client form
- [ ] Portal URL display + copy button
- [ ] Send intro email button
- [ ] Document requirements builder (add/remove/reorder)
- [ ] Reminder schedule configurator

### Client Detail Page
- [ ] Month tabs with status per month
- [ ] Per-requirement status with timestamps
- [ ] Per-file download
- [ ] Bulk download (ZIP) for selected month
- [ ] Reminder history
- [ ] Late rate stat
- [ ] Private notes field

### Reminder System
- [ ] Supabase Edge Function: send-reminders
- [ ] Cron schedule: runs 9am on days 1, 5, 10 of month
- [ ] Logic: check incomplete clients → send appropriate reminder number
- [ ] Resend integration with 5 email templates
- [ ] React Email templates (professional, not generic)
- [ ] Manual "Send reminder now" button

### Billing
- [ ] Stripe Checkout integration
- [ ] Stripe Webhook handler (subscription created/updated/deleted)
- [ ] Plan gating (free: 3 clients, starter: 15, pro: unlimited)
- [ ] Upgrade prompt when limit hit
- [ ] Stripe Customer Portal link (manage subscription)

### Settings
- [ ] Practice name, reply-to email
- [ ] Reminder tone selector
- [ ] Notification preferences
- [ ] Billing section

### Testing
- [ ] Unit tests: toCents/fromCents, portal_token generation
- [ ] Unit tests: submission status calculation
- [ ] Unit tests: late rate calculation
- [ ] Integration tests: upload flow (mock Supabase)
- [ ] Integration tests: reminder sending logic

---

## BLOCKED BY
Nothing currently blocked.

---

## DECISIONS NEEDED FROM VICTOR
None currently — all architecture decisions made in CLAUDE.md.

---

## NEXT SESSION START HERE:
→ Write 001_initial_schema.sql migration file
→ Write src/types/index.ts
→ Write src/lib/tenant.config.ts
→ Write src/lib/supabase.ts
Then immediately move to client upload page (highest priority screen).
